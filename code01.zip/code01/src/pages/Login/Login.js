import React from 'react';

import '../../assets/css/Index.css';

function Login() {
    return (
        <React.Fragment>

            <main className="tittle">
                <div >
                    <h1 id='Login'> Comming Soon!</h1>
                    
                </div>
            </main>



        </React.Fragment>
    )
}

export default Login;