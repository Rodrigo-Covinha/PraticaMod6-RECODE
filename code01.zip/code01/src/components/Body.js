import React from 'react';

import '../assets/css/Index.css';

function Body() {
    return (
        <React.Fragment>

            <main className="tittle">
                <div className="Titulo">
                    <h1> Venha Viajar com a gente!
                    </h1>
                    <a href="./Destinos.html" type="" id='botao' className="entre"> TESTE</a>
                </div>
            </main>



        </React.Fragment>
    )
}

export default Body;